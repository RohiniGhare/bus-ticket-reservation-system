package com.example.btr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtrV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
