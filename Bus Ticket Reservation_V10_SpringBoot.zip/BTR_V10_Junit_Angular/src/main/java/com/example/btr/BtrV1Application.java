package com.example.btr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtrV1Application {

	public static void main(String[] args) {
		SpringApplication.run(BtrV1Application.class, args);
	}

}
