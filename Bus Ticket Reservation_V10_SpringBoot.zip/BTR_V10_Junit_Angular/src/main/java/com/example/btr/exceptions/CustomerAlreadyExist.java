package com.example.btr.exceptions;

public class CustomerAlreadyExist extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerAlreadyExist(String message) {
		super(message);
	}
	
	

}
