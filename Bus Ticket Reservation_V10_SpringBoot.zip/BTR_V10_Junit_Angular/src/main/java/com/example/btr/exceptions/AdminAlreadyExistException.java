package com.example.btr.exceptions;

public class AdminAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AdminAlreadyExistException(String msg) {
		super(msg);
	}

}
